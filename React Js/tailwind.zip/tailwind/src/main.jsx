import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './assets/css/style.css'
import Home from './Components/Home'
import { BrowserRouter, Route, Routes } from 'react-router'
import AboutUs from './Components/AboutUs'
import ContactUs from './Components/ContactUs'
import ProductDetail from './Components/ProductDetail'

createRoot(document.getElementById('root')).render(
  <>
    <BrowserRouter>
      <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='about-us' element={<AboutUs/>} />
          <Route path='contact-us' element={<ContactUs/>} />
          <Route path='product-details/:product_id' element={<ProductDetail/>} />
      </Routes>
    </BrowserRouter>
  </>,
)
