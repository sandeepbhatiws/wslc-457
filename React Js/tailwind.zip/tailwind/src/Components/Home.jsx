import React, { useEffect, useState } from 'react'
import Header from './Common/Header'
import ProductSection from './ProductSection'
import axios from 'axios';

export default function Home() {

  const [menProducts, setMenProducts] = useState([]);
  const [womenProducts, setWomenProducts] = useState([]);

  useEffect(() => {
      axios.get('https://dummyjson.com/products?skip=0&limit=8')
      .then((result) => {
          setMenProducts(result.data.products);
      })
      .catch(() => {
          
      })
  }, []);

  useEffect(() => {
      axios.get('https://dummyjson.com/products?skip=8&limit=8')
      .then((result) => {
          setWomenProducts(result.data.products);
      })
      .catch(() => {
          
      })
  }, []);

  return (
    <>
        <Header/>
        <ProductSection title="Celebration wear for Men" description="Welcome to Bagtesh Fashion Buy Indian Men's Ethnic suits, Tuxedos, Sherwanis, Nehru jacket, Jodhpurs pants, Blazers, Shirts and much more." products={menProducts}/>

        <ProductSection title="Celebration wear for Women" description="Beautiful collection of Lehenga cholis, Sarees, Salwar suits for engagement, wedding and other ethnic occasions" products={womenProducts}/>
    </>
  )
}
