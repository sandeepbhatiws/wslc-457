import React, { useEffect, useState } from 'react'
import ProductCard from './Common/ProductCard'
import axios from 'axios';

export default function ProductSection({title, description, products}) {

    return (
        <>
            <div class="bg-white">
                <div class="mx-auto max-w-2xl px-4 py-16 sm:px-6 lg:max-w-7xl lg:px-8">
                    <h2 class="text-2xl font-bold tracking-tight text-gray-900 text-center mb-4">{title}</h2>

                    <p className='text-center'>{description}</p>

                    <div class="mt-6 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
                        
                        {
                            products.map((v,i) => {
                                return(
                                    <ProductCard key={i} data={v}/>
                                )
                            })
                        }

                    </div>
                </div>
            </div>

        </>
    )
}
