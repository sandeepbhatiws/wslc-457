import React from 'react'
import { Link } from 'react-router'

export default function ProductCard({data}) {

    return (
        <>
            <div class="group relative border border-gray-300">
                <img src={data.thumbnail} alt="Front of men&#039;s Basic Tee in black." class="aspect-square w-full rounded-md bg-gray-200 object-cover group-hover:opacity-75 lg:aspect-auto lg:h-80" />
                <div class="flex justify-between p-3">
                    <div>
                        <h3 class="text-sm text-gray-700">
                            <Link to={`/product-details/${data.id}`}>
                                <span aria-hidden="true" class="absolute inset-0"></span>
                                { data.title }
                            </Link>
                        </h3>
                        <p class="mt-1 text-sm text-gray-500">{data.category}</p>
                    </div>
                    <p class="text-sm font-medium text-gray-900">${data.price}</p>
                </div>
            </div>
        </>
    )
}
