import React from 'react'
import Header from './Common/Header'

export default function AboutUs() {
  return (
    <>
      <Header/>


      <div className='p-5 text-center'>About Us</div>
    </>
  )
}
