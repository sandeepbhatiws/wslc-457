import React from 'react'
import Header from './Common/Header'

export default function ContactUs() {
    return (
        <>
            <Header />

            <div className='p-5 text-center'>Contact Us</div>
        </>
    )
}
