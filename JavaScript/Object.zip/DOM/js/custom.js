
// const data = document.getElementById('row2').innerText;

// const data = document.getElementsByClassName('row');

// const data = document.getElementsByTagName('div');

var data = document.querySelector('#row');
var data = document.querySelector('div');

var data = document.querySelectorAll('#row');
var data = document.querySelectorAll('.row');
var data = document.querySelectorAll('div');

console.log(data);